<?php
return [
    'APP_NAME'=>'IA ESF ENTERPRISE',
    'ALERT_EMAIL_TO'=>'alerta@seudominio.gov.br',
    'ALERT_EMAIL_FROM'=>'ia-esf@seudominio.gov.br',
    'TIMEZONE'=>'America/Sao_Paulo'
];
