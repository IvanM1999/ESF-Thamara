export default {
  "saudacao": "Ol\u00e1! Sou a IA da ESF Thamara. Posso ajudar com hor\u00e1rios, vacinas, endere\u00e7o ou triagem.",
  "horarios": "Atendimento de segunda a sexta. Fechado das 12h \u00e0s 13h.",
  "endereco": "Rua Santa Maria, 2082 \u2013 Bairro Progresso \u2013 Blumenau/SC.",
  "vacinas": "Vacina\u00e7\u00e3o de segunda a sexta em hor\u00e1rios espec\u00edficos. Traga cart\u00e3o SUS.",
  "emergencia": "\ud83d\udea8 Emerg\u00eancia detectada. Ligue 192 imediatamente.",
  "fallback": "Posso ajudar com informa\u00e7\u00f5es da unidade ou orienta\u00e7\u00e3o inicial de sa\u00fade."
};